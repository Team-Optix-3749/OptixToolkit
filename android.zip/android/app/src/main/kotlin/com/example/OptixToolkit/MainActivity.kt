package org.team3749.toolkit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
